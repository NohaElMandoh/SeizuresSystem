<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SeizureUnit extends Model
{
    use HasFactory;
    protected $table ='seizures_unites';
    protected $guarded =[];
}
